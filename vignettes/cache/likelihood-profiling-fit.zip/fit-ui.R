ui <- function () 
{
    ini({
        tka <- 0.401538298360021
        tcl <- 1.02788361214878
        tv <- 3.42952551411756
        add.sd <- c(0, 0.781905243349549)
        eta.ka ~ 0.329035498751406
        eta.cl ~ 0.121102205441781
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv)
        cp <- linCmt()
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "oneCmt", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

