ui <- function () 
{
    ini({
        m <- 2.97897242631246
        pop.b <- 6.65293058865328
        cov_w_b <- -0.179775729643511
        addSd <- c(0, 4.56129253013201)
        bRe ~ 0.0202890612365497
    })
    model({
        b <- pop.b + cov_w_b * w
        value <- m * x + b + bRe
        value ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "$", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

