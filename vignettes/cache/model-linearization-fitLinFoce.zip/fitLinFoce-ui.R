ui <- function () 
{
    ini({
        add.sd <- c(0, 2.88776961789099)
        theta.etaTcl <- fix(0)
        theta.etaTv <- fix(0)
        theta.etaTka <- fix(0)
        etaTcl ~ fix(0.001)
        etaTv ~ fix(0.001)
        etaTka ~ fix(0.001)
    })
    model({
        mu_etaTcl = theta.etaTcl + etaTcl
        mu_etaTv = theta.etaTv + etaTv
        mu_etaTka = theta.etaTka + etaTka
        base_etaTcl = D_etaTcl * (-O_etaTcl + mu_etaTcl)
        base_etaTv = D_etaTv * (-O_etaTv + mu_etaTv)
        base_etaTka = D_etaTka * (-O_etaTka + mu_etaTka)
        BASE_TERMS = base_etaTcl + base_etaTv + base_etaTka
        y = BASE_TERMS + OPRED
        err_etaTcl = D_VAR_etaTcl * (-O_etaTcl + etaTcl)
        err_etaTv = D_VAR_etaTv * (-O_etaTv + etaTv)
        err_etaTka = D_VAR_etaTka * (-O_etaTka + etaTka)
        rxR2 <- (add.sd)^2
        fct <- 1
        r <- sqrt(rxR2)
        foceiLin <- 0
        BASE_ERROR = foceiLin * fct * (err_etaTcl + err_etaTv + 
            err_etaTka)/(2 * r) + r
        rxR = BASE_ERROR
        TIPRED <- y
        y1 <- y
        y1 ~ add(rxR)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "nlmod", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

