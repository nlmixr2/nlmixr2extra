ui <- function () 
{
    ini({
        b.timeF.0 <- 3.34057424840346
        b.timeF.0.5 <- -6.40637210226533
        b.timeF.1 <- 2.47400472381038
        b.timeF.1.5 <- -3.3147280877144
        b.timeF.2 <- 2.09265322223496
        b.timeF.3 <- -1.38626526523883
        b.timeF.4 <- -4.01871273557101
        b.timeF.6 <- -4.26740350571212
        b.timeF.8 <- 1.60650888823892
        b.timeF.12 <- -5.23069004859002
        cov_conc_b <- 0.0100733284594822
        addSd <- c(0, 3.0783579335578)
    })
    model({
        b <- b.timeF.0 + b.timeF.0.5 * (timeF == "0.5") + b.timeF.1 * 
            (timeF == "1") + b.timeF.1.5 * (timeF == "1.5") + 
            b.timeF.2 * (timeF == "2") + b.timeF.3 * (timeF == 
            "3") + b.timeF.4 * (timeF == "4") + b.timeF.6 * (timeF == 
            "6") + b.timeF.8 * (timeF == "8") + b.timeF.12 * 
            (timeF == "12") + cov_conc_b * conc
        value <- b
        value ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "$", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

