foceiModel <- list()

foceiModel[["inner"]] <- NULL

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- NULL

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],THETA[7],THETA[8],THETA[9],THETA[10],THETA[11],THETA[12],timeF,conc);\nrx_yj_~162;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~conc*THETA[11];\nrx_expr_1~timeF==\"8\";\nrx_expr_2~timeF==\"1\";\nrx_expr_3~timeF==\"2\";\nrx_expr_4~timeF==\"3\";\nrx_expr_5~timeF==\"4\";\nrx_expr_6~timeF==\"6\";\nrx_expr_7~timeF==\"12\";\nrx_expr_8~timeF==\"0.5\";\nrx_expr_9~timeF==\"1.5\";\nrx_expr_10~THETA[9]*(rx_expr_1);\nrx_expr_11~(rx_expr_2)*THETA[3];\nrx_expr_12~(rx_expr_3)*THETA[5];\nrx_expr_13~(rx_expr_4)*THETA[6];\nrx_expr_14~(rx_expr_5)*THETA[7];\nrx_expr_15~(rx_expr_6)*THETA[8];\nrx_expr_16~THETA[10]*(rx_expr_7);\nrx_expr_17~(rx_expr_8)*THETA[2];\nrx_expr_18~(rx_expr_9)*THETA[4];\nrx_expr_19~THETA[1]+rx_expr_16;\nrx_expr_20~rx_expr_19+rx_expr_10;\nrx_expr_21~rx_expr_20+rx_expr_0;\nrx_expr_22~rx_expr_21+rx_expr_17;\nrx_expr_23~rx_expr_22+rx_expr_18;\nrx_expr_24~rx_expr_23+rx_expr_11;\nrx_expr_25~rx_expr_24+rx_expr_12;\nrx_expr_26~rx_expr_25+rx_expr_13;\nrx_expr_27~rx_expr_26+rx_expr_14;\nrx_expr_28~rx_expr_27+rx_expr_15;\nrx_pred_=rx_expr_28;\nrx_r_=Rx_pow_di(THETA[12],2);\nb.timeF.0=THETA[1];\nb.timeF.0.5=THETA[2];\nb.timeF.1=THETA[3];\nb.timeF.1.5=THETA[4];\nb.timeF.2=THETA[5];\nb.timeF.3=THETA[6];\nb.timeF.4=THETA[7];\nb.timeF.6=THETA[8];\nb.timeF.8=THETA[9];\nb.timeF.12=THETA[10];\ncov_conc_b=THETA[11];\naddSd=THETA[12];\nb=rx_expr_28;\nvalue=rx_expr_28;\ntad=tad();\ndosenum=dosenum();\ncmt(value);\ndvid(1);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- NULL

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- integer(0)

foceiModel[["predOnlyLlik"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],THETA[5],THETA[6],THETA[7],THETA[8],THETA[9],THETA[10],THETA[11],THETA[12],timeF,conc,DV);\nrx_yj_~162;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~conc*THETA[11];\nrx_expr_1~timeF==\"8\";\nrx_expr_2~timeF==\"1\";\nrx_expr_3~timeF==\"2\";\nrx_expr_4~timeF==\"3\";\nrx_expr_5~timeF==\"4\";\nrx_expr_6~timeF==\"6\";\nrx_expr_7~timeF==\"12\";\nrx_expr_8~timeF==\"0.5\";\nrx_expr_9~timeF==\"1.5\";\nrx_expr_10~Rx_pow_di(THETA[12],2);\nrx_expr_11~THETA[9]*(rx_expr_1);\nrx_expr_12~(rx_expr_2)*THETA[3];\nrx_expr_13~(rx_expr_3)*THETA[5];\nrx_expr_14~(rx_expr_4)*THETA[6];\nrx_expr_15~(rx_expr_5)*THETA[7];\nrx_expr_16~(rx_expr_6)*THETA[8];\nrx_expr_17~sqrt(rx_expr_10);\nrx_expr_18~THETA[10]*(rx_expr_7);\nrx_expr_19~(rx_expr_8)*THETA[2];\nrx_expr_20~(rx_expr_9)*THETA[4];\nrx_expr_21~THETA[1]+rx_expr_18;\nrx_expr_22~rx_expr_21+rx_expr_11;\nrx_expr_23~rx_expr_22+rx_expr_0;\nrx_expr_24~rx_expr_23+rx_expr_19;\nrx_expr_25~rx_expr_24+rx_expr_20;\nrx_expr_26~rx_expr_25+rx_expr_12;\nrx_expr_27~rx_expr_26+rx_expr_13;\nrx_expr_28~rx_expr_27+rx_expr_14;\nrx_expr_29~rx_expr_28+rx_expr_15;\nrx_expr_30~rx_expr_29+rx_expr_16;\nrx_pred_=llikNorm(DV,rx_expr_30,rx_expr_17);\nrx_r_=Rx_pow_di((rx_expr_17),2);\nrx_pred_f_=rx_expr_30;\nb.timeF.0=THETA[1];\nb.timeF.0.5=THETA[2];\nb.timeF.1=THETA[3];\nb.timeF.1.5=THETA[4];\nb.timeF.2=THETA[5];\nb.timeF.3=THETA[6];\nb.timeF.4=THETA[7];\nb.timeF.6=THETA[8];\nb.timeF.8=THETA[9];\nb.timeF.12=THETA[10];\ncov_conc_b=THETA[11];\naddSd=THETA[12];\nb=rx_expr_30;\nvalue=rx_expr_30;\ntad=tad();\ndosenum=dosenum();\ncmt(value);\ndvid(1);\n")

class(foceiModel) <- "foceiModelList"

