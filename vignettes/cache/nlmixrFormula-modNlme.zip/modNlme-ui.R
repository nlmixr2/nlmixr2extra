ui <- function () 
{
    ini({
        m <- 2.67377079809971
        b <- 6.5660938824988
        addSd <- c(0, 5.09892871374344)
        bRe ~ 2.641065662879
    })
    model({
        value <- m * x + b + bRe
        value ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "$", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

