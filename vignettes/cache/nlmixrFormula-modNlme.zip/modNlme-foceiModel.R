foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1],x);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=ETA[1]+THETA[2]+x*THETA[1];\nrx__sens_rx_pred__BY_ETA_1___=1;\nrx_r_=Rx_pow_di(THETA[3],2);\nrx__sens_rx_r__BY_ETA_1___=0;\ncmt(value);\ndvid(1);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_pred_=ETA[1]+THETA[2]+x*THETA[1]\nrx__sens_rx_pred__BY_ETA_1___=1\nrx_r_=Rx_pow_di(THETA[3], 2)\nrx__sens_rx_r__BY_ETA_1___=0\nrx__ETA1=ETA[1]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1],x);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~x*THETA[1];\nrx_expr_1~ETA[1]+THETA[2];\nrx_expr_2~rx_expr_1+rx_expr_0;\nrx_pred_=rx_expr_2;\nrx_r_=Rx_pow_di(THETA[3],2);\nm=THETA[1];\nb=THETA[2];\naddSd=THETA[3];\nbRe=ETA[1];\nvalue=rx_expr_2;\ntad=tad();\ndosenum=dosenum();\ncmt(value);\ndvid(1);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],ETA[1],x);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_pred_=ETA[1]+THETA[2]+x*THETA[1];\nrx_r_=Rx_pow_di(THETA[3],2);\ncmt(value);\ndvid(1);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L)

foceiModel[["eventEta"]] <- 0L

class(foceiModel) <- "foceiModelList"

