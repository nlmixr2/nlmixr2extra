ui <- function () 
{
    ini({
        tka <- 0.40152294819305
        tcl <- 1.02757297939784
        tv <- 3.42949755396278
        add.sd <- c(0, 0.782076361245257)
        eta.ka ~ 0.328876097869629
        eta.cl ~ 0.120850035403409
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv)
        linCmt() ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "one.compartment", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

