foceiModel <- list()

foceiModel[["inner"]] <- NULL

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- NULL

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],x);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~x*THETA[1];\nrx_expr_1~THETA[2]+rx_expr_0;\nrx_pred_=rx_expr_1;\nrx_r_=Rx_pow_di(THETA[3],2);\nm=THETA[1];\nb=THETA[2];\naddSd=THETA[3];\nvalue=rx_expr_1;\ntad=tad();\ndosenum=dosenum();\ncmt(value);\ndvid(1);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- NULL

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L)

foceiModel[["eventEta"]] <- integer(0)

class(foceiModel) <- "foceiModelList"

