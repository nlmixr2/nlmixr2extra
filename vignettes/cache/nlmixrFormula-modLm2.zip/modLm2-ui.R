ui <- function () 
{
    ini({
        m <- 2.99971442720417
        b <- 5.17259182849315
        addSd <- c(0, 4.70257099012729)
    })
    model({
        value <- m * x + b
        value ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "$", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

