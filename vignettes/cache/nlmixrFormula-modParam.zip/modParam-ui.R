ui <- function () 
{
    ini({
        m <- 2.99139646762844
        b.z.b <- 5.92675618933135
        b.z.a <- -0.552572379896127
        addSd <- c(0, 4.61639078072479)
        bRe ~ 0.383837791104109
    })
    model({
        b <- b.z.b + b.z.a * (z == "a")
        value <- m * x + b + bRe
        value ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "$", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

