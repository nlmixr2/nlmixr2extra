foceiModel <- list()

foceiModel[["inner"]] <- NULL

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- NULL

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],conc);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~conc*THETA[2];\nrx_expr_1~THETA[3]+conc;\nrx_expr_2~rx_expr_0/(rx_expr_1);\nrx_expr_3~THETA[1]+rx_expr_2;\nrx_pred_=rx_expr_3;\nrx_r_=Rx_pow_di(THETA[4],2);\ne0=THETA[1];\nemax=THETA[2];\nec50=THETA[3];\naddSd=THETA[4];\neffect=rx_expr_3;\ntad=tad();\ndosenum=dosenum();\ncmt(effect);\ndvid(1);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- NULL

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- integer(0)

class(foceiModel) <- "foceiModelList"

