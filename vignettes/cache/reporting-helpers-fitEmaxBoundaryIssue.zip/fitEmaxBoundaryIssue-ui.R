ui <- function () 
{
    ini({
        e0 <- 0.948497443475347
        emax <- 4.05469486849579
        ec50 <- c(0, 0.00165911650027417)
        addSd <- c(0, 0.009977935285712)
    })
    model({
        effect <- e0 + emax * conc/(ec50 + conc)
        effect ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "modEmax", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

