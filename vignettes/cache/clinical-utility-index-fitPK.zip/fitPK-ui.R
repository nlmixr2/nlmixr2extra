ui <- function () 
{
    ini({
        tka <- 0.162226208880223
        tcl <- 2.09171318129019
        tv <- 4.10320510124198
        prop.sd <- c(0, 0.156052786020201)
        eta.cl ~ 0.0782788395759263
        eta.v ~ 0.0364849860388655
    })
    model({
        ka <- exp(tka)
        cl <- exp(tcl + eta.cl) * (WT/70)^0.75
        v <- exp(tv + eta.v)
        cp <- linCmt()
        cp ~ prop(prop.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "pkModel", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

