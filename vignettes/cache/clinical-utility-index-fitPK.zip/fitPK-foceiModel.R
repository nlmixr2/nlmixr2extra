foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2],WT);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~exp(THETA[1]);\nrx_expr_1~ETA[1]+THETA[2];\nrx_expr_2~ETA[2]+THETA[3];\nrx_expr_3~Rx_pow(WT,0.75);\nrx_expr_4~exp(rx_expr_1);\nrx_expr_5~exp(rx_expr_2);\nrx_expr_8~0.0413215372645583*rx_expr_4;\nrx_expr_11~rx_expr_8*rx_expr_3;\nrx_pred_=linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_11,rx_expr_5,0,0,0,0,rx_expr_0);\nrx_lcCarryAdv_~linCmtB(rx__PTR__,t,2,1,1,-5,0,1,rx_expr_11,rx_expr_5,0,0,0,0,rx_expr_0);\nrx_lcCarryG0_~rx_expr_11;\nrx_lcCarryJ0r0_~linCmtB(rx__PTR__,t,2,1,1,0,0,1,0,0,0,0,0,0,0);\nrx_lcCarryP0r0_~linCmtB(rx__PTR__,t,2,1,1,-6,2,1,0,0,0,0,0,0,0);\nrx_expr_6~rx_lcCarryJ0r0_-rx_lcCarryP0r0_;\nrx_lcCarryS0r0_~linCmtB(rx__PTR__,t,2,1,1,-7,0,1,0,0,rx_lcCarryG0_*(rx_expr_6),0,0,0,0);\nrx_lcCarryU0r0_~linCmtB(rx__PTR__,t,2,1,1,-7,2,1,0,0,(rx_expr_6),0,0,0,0);\nrx_lcCarryJ0r1_~linCmtB(rx__PTR__,t,2,1,1,1,0,1,0,0,0,0,0,0,0);\nrx_lcCarryP0r1_~linCmtB(rx__PTR__,t,2,1,1,-6,3,1,0,0,0,0,0,0,0);\nrx_expr_7~rx_lcCarryJ0r1_-rx_lcCarryP0r1_;\nrx_lcCarryS0r1_~linCmtB(rx__PTR__,t,2,1,1,-7,1,1,0,0,rx_lcCarryG0_*(rx_expr_7),0,0,0,0);\nrx_lcCarryU0r1_~linCmtB(rx__PTR__,t,2,1,1,-7,3,1,0,0,(rx_expr_7),0,0,0,0);\nrx__sens_rx_pred__BY_ETA_1___=rx_lcCarryS0r1_/(rx_expr_5);\nrx_expr_10~(rx__sens_central_BY_v1)/(rx_expr_5);\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_5*(-(central)/((rx_expr_5)*(rx_expr_5))+rx_expr_10);\nrx_r_=Rx_pow_di((linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_11,rx_expr_5,0,0,0,0,rx_expr_0)*THETA[4]),2);\nrx__sens_rx_r__BY_ETA_1___=(2*(linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_11,rx_expr_5,0,0,0,0,rx_expr_0)*THETA[4])*THETA[4])*rx__sens_rx_pred__BY_ETA_1___;\nrx__sens_rx_r__BY_ETA_2___=2*rx_expr_5*(linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_11,rx_expr_5,0,0,0,0,rx_expr_0)*THETA[4])*(-(central)/((rx_expr_5)*(rx_expr_5))+rx_expr_10)*THETA[4];\ncmt(cp);\ndvid(3);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_0~exp(THETA[1])\nrx_expr_1~ETA[1]+THETA[2]\nrx_expr_2~ETA[2]+THETA[3]\nrx_expr_3~Rx_pow(WT, 0.75)\nrx_expr_4~exp(rx_expr_1)\nrx_expr_5~exp(rx_expr_2)\nrx_expr_8~0.0413215372645583*rx_expr_4\nrx_expr_11~rx_expr_8*rx_expr_3\nrx_pred_=linCmtB(rx__PTR__, t, 2, 1, 1, -1, -1, 1, rx_expr_11, rx_expr_5, 0, 0, 0, 0, rx_expr_0)\nrx_lcCarryAdv_~linCmtB(rx__PTR__, t, 2, 1, 1, -5, 0, 1, rx_expr_11, rx_expr_5, 0, 0, 0, 0, rx_expr_0)\nrx_lcCarryG0_~rx_expr_11\nrx_lcCarryJ0r0_~linCmtB(rx__PTR__, t, 2, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0)\nrx_lcCarryP0r0_~linCmtB(rx__PTR__, t, 2, 1, 1, -6, 2, 1, 0, 0, 0, 0, 0, 0, 0)\nrx_expr_6~rx_lcCarryJ0r0_-rx_lcCarryP0r0_\nrx_lcCarryS0r0_~linCmtB(rx__PTR__, t, 2, 1, 1, -7, 0, 1, 0, 0, rx_lcCarryG0_*(rx_expr_6), 0, 0, 0, 0)\nrx_lcCarryU0r0_~linCmtB(rx__PTR__, t, 2, 1, 1, -7, 2, 1, 0, 0, (rx_expr_6), 0, 0, 0, 0)\nrx_lcCarryJ0r1_~linCmtB(rx__PTR__, t, 2, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0)\nrx_lcCarryP0r1_~linCmtB(rx__PTR__, t, 2, 1, 1, -6, 3, 1, 0, 0, 0, 0, 0, 0, 0)\nrx_expr_7~rx_lcCarryJ0r1_-rx_lcCarryP0r1_\nrx_lcCarryS0r1_~linCmtB(rx__PTR__, t, 2, 1, 1, -7, 1, 1, 0, 0, rx_lcCarryG0_*(rx_expr_7), 0, 0, 0, 0)\nrx_lcCarryU0r1_~linCmtB(rx__PTR__, t, 2, 1, 1, -7, 3, 1, 0, 0, (rx_expr_7), 0, 0, 0, 0)\nrx__sens_rx_pred__BY_ETA_1___=rx_lcCarryS0r1_/(rx_expr_5)\nrx_expr_10~(rx__sens_central_BY_v1)/(rx_expr_5)\nrx__sens_rx_pred__BY_ETA_2___=rx_expr_5*(-(central)/((rx_expr_5)*(rx_expr_5))+rx_expr_10)\nrx_r_=Rx_pow_di((linCmtB(rx__PTR__, t, 2, 1, 1, -1, -1, 1, rx_expr_11, rx_expr_5, 0, 0, 0, 0, rx_expr_0)*THETA[4]), 2)\nrx__sens_rx_r__BY_ETA_1___=(2*(linCmtB(rx__PTR__, t, 2, 1, 1, -1, -1, 1, rx_expr_11, rx_expr_5, 0, 0, 0, 0, rx_expr_0)*THETA[4])*THETA[4])*rx__sens_rx_pred__BY_ETA_1___\nrx__sens_rx_r__BY_ETA_2___=2*rx_expr_5*(linCmtB(rx__PTR__, t, 2, 1, 1, -1, -1, 1, rx_expr_11, rx_expr_5, 0, 0, 0, 0, rx_expr_0)*THETA[4])*(-(central)/((rx_expr_5)*(rx_expr_5))+rx_expr_10)*THETA[4]\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2],WT);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~exp(THETA[1]);\nrx_expr_1~ETA[1]+THETA[2];\nrx_expr_2~ETA[2]+THETA[3];\nrx_expr_3~Rx_pow(WT,0.75);\nrx_expr_4~exp(rx_expr_1);\nrx_expr_5~exp(rx_expr_2);\nrx_expr_6~0.0413215372645583*rx_expr_4;\nrx_expr_7~rx_expr_6*rx_expr_3;\nrx_pred_=linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_7,rx_expr_5,0,0,0,0,rx_expr_0);\nrx_r_=Rx_pow_di((linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_7,rx_expr_5,0,0,0,0,rx_expr_0)*THETA[4]),2);\ntka=THETA[1];\ntcl=THETA[2];\ntv=THETA[3];\nprop.sd=THETA[4];\neta.cl=ETA[1];\neta.v=ETA[2];\nka=rx_expr_0;\ncl=rx_expr_7;\nv=rx_expr_5;\ncp=linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_7,rx_expr_5,0,0,0,0,rx_expr_0);\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(3);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4],ETA[1],ETA[2],WT);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~exp(THETA[1]);\nrx_expr_1~ETA[1]+THETA[2];\nrx_expr_2~ETA[2]+THETA[3];\nrx_expr_3~Rx_pow(WT,0.75);\nrx_expr_4~exp(rx_expr_1);\nrx_expr_5~exp(rx_expr_2);\nrx_expr_6~0.0413215372645583*rx_expr_4;\nrx_expr_7~rx_expr_6*rx_expr_3;\nrx_pred_=linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_7,rx_expr_5,0,0,0,0,rx_expr_0);\nrx_r_=Rx_pow_di((linCmtB(rx__PTR__,t,2,1,1,-1,-1,1,rx_expr_7,rx_expr_5,0,0,0,0,rx_expr_0)*THETA[4]),2);\ncmt(cp);\ndvid(3);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- c(0L, 0L)

foceiModel[["eventEtaAll"]] <- c(0L, 0L)

class(foceiModel) <- "foceiModelList"

