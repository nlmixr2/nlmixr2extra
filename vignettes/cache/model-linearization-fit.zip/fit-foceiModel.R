foceiModel <- list()

foceiModel[["inner"]] <- NULL

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- NULL

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],THETA[2],THETA[3],THETA[4]);\ncmt(depot);\ncmt(center);\nrx_expr_0~exp(THETA[3]);\nd/dt(depot)=-rx_expr_0*depot;\nd/dt(center)=rx_expr_0*depot-exp(THETA[1]-THETA[2])*center;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_1~exp(-THETA[2]);\nrx_expr_2~rx_expr_1*center;\nrx_pred_=rx_expr_2;\nrx_r_=Rx_pow_di(THETA[4],2);\ntcl=THETA[1];\ntv=THETA[2];\ntka=THETA[3];\nadd.sd=THETA[4];\nka=rx_expr_0;\ncl=exp(THETA[1]);\nv=exp(THETA[2]);\ncp=rx_expr_2;\ntad=tad();\ndosenum=dosenum();\ncmt(cp);\ndvid(3);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- NULL

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- c(0L, 0L, 0L, 0L)

foceiModel[["eventEta"]] <- integer(0)

class(foceiModel) <- "foceiModelList"

