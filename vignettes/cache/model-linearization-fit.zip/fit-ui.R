ui <- function () 
{
    ini({
        tcl <- 0.932765952601939
        tv <- 3.23096564206471
        tka <- 0.471817817963012
        add.sd <- c(0, 2.97411724013051)
    })
    model({
        ka <- exp(tka)
        cl <- exp(tcl)
        v <- exp(tv)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "oneCmtBase", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

