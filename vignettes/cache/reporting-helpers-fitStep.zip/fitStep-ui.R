ui <- function () 
{
    ini({
        e0 <- 1.00006404228524
        emax <- 3.99992667548472
        addSd <- c(0, 9.19710604246003e-06)
    })
    model({
        effect <- e0 + emax * (conc > 0)
        effect ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "modStep", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

