foceiModel <- list()

foceiModel[["inner"]] <- rxode2::rxode2("param(THETA[1],ETA[1],ETA[2],ETA[3],D_etaTcl,O_etaTcl,D_etaTv,O_etaTv,D_etaTka,O_etaTka,OPRED,D_VAR_etaTcl,D_VAR_etaTv,D_VAR_etaTka);\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~ETA[2]-O_etaTv;\nrx_expr_1~ETA[1]-O_etaTcl;\nrx_expr_2~ETA[3]-O_etaTka;\nrx_pred_=OPRED+D_etaTv*(rx_expr_0)+(rx_expr_1)*D_etaTcl+(rx_expr_2)*D_etaTka;\nrx__sens_rx_pred__BY_ETA_1___=D_etaTcl;\nrx__sens_rx_pred__BY_ETA_2___=D_etaTv;\nrx__sens_rx_pred__BY_ETA_3___=D_etaTka;\nrx_expr_3~Rx_pow_di(THETA[1],2);\nrx_expr_4~(rx_expr_0)*D_VAR_etaTv;\nrx_expr_5~sqrt(rx_expr_3);\nrx_expr_6~(rx_expr_1)*D_VAR_etaTcl;\nrx_expr_7~(rx_expr_2)*D_VAR_etaTka;\nrx_expr_8~rx_expr_6+rx_expr_4;\nrx_expr_9~rx_expr_8+rx_expr_7;\nrx_expr_10~0.5*(rx_expr_9);\nrx_expr_11~rx_expr_10/rx_expr_5;\nrx_r_=Rx_pow_di((rx_expr_11+rx_expr_5),2);\nrx__sens_rx_r__BY_ETA_1___=(rx_expr_11+rx_expr_5)*D_VAR_etaTcl/rx_expr_5;\nrx__sens_rx_r__BY_ETA_2___=(rx_expr_11+rx_expr_5)*D_VAR_etaTv/rx_expr_5;\nrx__sens_rx_r__BY_ETA_3___=(rx_expr_11+rx_expr_5)*D_VAR_etaTka/rx_expr_5;\ncmt(y1);\ndvid(1);\n")

foceiModel[["innerHess2"]] <- NULL

foceiModel[["innerOeta"]] <- "rx_yj_~2\nrx_lambda_~1\nrx_hi_~1\nrx_low_~0\nrx_expr_0~ETA[2]-O_etaTv\nrx_expr_1~ETA[1]-O_etaTcl\nrx_expr_2~ETA[3]-O_etaTka\nrx_pred_=OPRED+D_etaTv*(rx_expr_0)+(rx_expr_1)*D_etaTcl+(rx_expr_2)*D_etaTka\nrx__sens_rx_pred__BY_ETA_1___=D_etaTcl\nrx__sens_rx_pred__BY_ETA_2___=D_etaTv\nrx__sens_rx_pred__BY_ETA_3___=D_etaTka\nrx_expr_3~Rx_pow_di(THETA[1], 2)\nrx_expr_4~(rx_expr_0)*D_VAR_etaTv\nrx_expr_5~sqrt(rx_expr_3)\nrx_expr_6~(rx_expr_1)*D_VAR_etaTcl\nrx_expr_7~(rx_expr_2)*D_VAR_etaTka\nrx_expr_8~rx_expr_6+rx_expr_4\nrx_expr_9~rx_expr_8+rx_expr_7\nrx_expr_10~0.5*(rx_expr_9)\nrx_expr_11~rx_expr_10/rx_expr_5\nrx_r_=Rx_pow_di((rx_expr_11+rx_expr_5), 2)\nrx__sens_rx_r__BY_ETA_1___=(rx_expr_11+rx_expr_5)*D_VAR_etaTcl/rx_expr_5\nrx__sens_rx_r__BY_ETA_2___=(rx_expr_11+rx_expr_5)*D_VAR_etaTv/rx_expr_5\nrx__sens_rx_r__BY_ETA_3___=(rx_expr_11+rx_expr_5)*D_VAR_etaTka/rx_expr_5\nrx__ETA1=ETA[1]\nrx__ETA2=ETA[2]\nrx__ETA3=ETA[3]"

foceiModel[["predOnly"]] <- rxode2::rxode2("param(THETA[1],ETA[1],ETA[2],ETA[3],D_etaTcl,O_etaTcl,D_etaTv,O_etaTv,D_etaTka,O_etaTka,OPRED,D_VAR_etaTcl,D_VAR_etaTv,D_VAR_etaTka);\nfct=1;\nfoceiLin=1;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~ETA[2]-O_etaTv;\nrx_expr_1~ETA[1]-O_etaTcl;\nrx_expr_2~ETA[3]-O_etaTka;\nrx_expr_4~D_etaTv*(rx_expr_0);\nrx_expr_5~(rx_expr_1)*D_etaTcl;\nrx_expr_6~(rx_expr_2)*D_etaTka;\nrx_expr_9~OPRED+rx_expr_4;\nrx_expr_12~rx_expr_9+rx_expr_5;\nrx_expr_14~rx_expr_12+rx_expr_6;\nrx_pred_=rx_expr_14;\nrx_expr_3~Rx_pow_di(THETA[1],2);\nrx_expr_7~(rx_expr_0)*D_VAR_etaTv;\nrx_expr_8~sqrt(rx_expr_3);\nrx_expr_10~(rx_expr_1)*D_VAR_etaTcl;\nrx_expr_11~(rx_expr_2)*D_VAR_etaTka;\nrx_expr_13~rx_expr_10+rx_expr_7;\nrx_expr_15~rx_expr_13+rx_expr_11;\nrx_expr_16~0.5*(rx_expr_15);\nrx_expr_17~rx_expr_16/rx_expr_8;\nrx_r_=Rx_pow_di((rx_expr_17+rx_expr_8),2);\nadd.sd=THETA[1];\netaTcl=ETA[1];\netaTv=ETA[2];\netaTka=ETA[3];\nmu_etaTcl=ETA[1];\nmu_etaTv=ETA[2];\nmu_etaTka=ETA[3];\nbase_etaTcl=rx_expr_5;\nbase_etaTv=rx_expr_4;\nbase_etaTka=rx_expr_6;\nBASE_TERMS=rx_expr_4+rx_expr_5+rx_expr_6;\ny=rx_expr_14;\nerr_etaTcl=rx_expr_10;\nerr_etaTv=rx_expr_7;\nerr_etaTka=rx_expr_11;\nrxR2=rx_expr_3;\nr=rx_expr_8;\nBASE_ERROR=rx_expr_17+rx_expr_8;\nrxR=rx_expr_17+rx_expr_8;\nTIPRED=rx_expr_14;\ny1=rx_expr_14;\ntad=tad();\ndosenum=dosenum();\ncmt(y1);\ndvid(1);\n")

foceiModel[["extra.pars"]] <- NULL

foceiModel[["outer"]] <- NULL

foceiModel[["outerMeta"]] <- NULL

foceiModel[["outerPoolOk"]] <- TRUE

foceiModel[["outerNode"]] <- NULL

foceiModel[["outerNodeMeta"]] <- NULL

foceiModel[["predNoLhs"]] <- rxode2::rxode2("param(THETA[1],ETA[1],ETA[2],ETA[3],D_etaTcl,O_etaTcl,D_etaTv,O_etaTv,D_etaTka,O_etaTka,OPRED,D_VAR_etaTcl,D_VAR_etaTv,D_VAR_etaTka);\nfct=1;\nfoceiLin=1;\nrx_yj_~2;\nrx_lambda_~1;\nrx_hi_~1;\nrx_low_~0;\nrx_expr_0~ETA[2]-O_etaTv;\nrx_expr_1~ETA[1]-O_etaTcl;\nrx_expr_2~ETA[3]-O_etaTka;\nrx_pred_=OPRED+D_etaTv*(rx_expr_0)+(rx_expr_1)*D_etaTcl+(rx_expr_2)*D_etaTka;\nrx_expr_3~Rx_pow_di(THETA[1],2);\nrx_expr_4~sqrt(rx_expr_3);\nrx_r_=Rx_pow_di((0.5*((rx_expr_1)*D_VAR_etaTcl+(rx_expr_0)*D_VAR_etaTv+(rx_expr_2)*D_VAR_etaTka)/rx_expr_4+rx_expr_4),2);\ncmt(y1);\ndvid(1);\n")

foceiModel[["theta"]] <- NULL

foceiModel[["pred.minus.dv"]] <- TRUE

foceiModel[["log.thetas"]] <- integer(0)

foceiModel[["log.etas"]] <- integer(0)

foceiModel[["extraProps"]] <- list()

foceiModel[["eventTheta"]] <- 0L

foceiModel[["eventEta"]] <- c(0L, 0L, 0L)

class(foceiModel) <- "foceiModelList"

