ui <- function () 
{
    ini({
        b.timeF.0 <- 3.40883433042518
        b.timeF.0.5 <- 1.95795910933065
        b.timeF.1 <- -4.13229313227227
        b.timeF.1.5 <- -1.50482944672731
        b.timeF.2 <- -4.37416289536051
        b.timeF.3 <- -5.33195213929555
        b.timeF.4 <- -6.51742598081326
        b.timeF.6 <- -3.38811114010699
        b.timeF.8 <- 2.34198508179978
        b.timeF.12 <- 1.49271434029692
        cov_conc_b <- 0.0101156565913706
        addSd <- c(0, 3.07715572920372)
        bRe ~ 0.0100000163024171
    })
    model({
        b <- b.timeF.0 + b.timeF.0.5 * (timeF == "0.5") + b.timeF.1 * 
            (timeF == "1") + b.timeF.1.5 * (timeF == "1.5") + 
            b.timeF.2 * (timeF == "2") + b.timeF.3 * (timeF == 
            "3") + b.timeF.4 * (timeF == "4") + b.timeF.6 * (timeF == 
            "6") + b.timeF.8 * (timeF == "8") + b.timeF.12 * 
            (timeF == "12") + cov_conc_b * conc
        value <- b + bRe
        value ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "$", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

