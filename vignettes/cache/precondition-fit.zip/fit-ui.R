ui <- function () 
{
    ini({
        tka <- 0.466714015123778
        tcl <- 1.01275731561729
        tv <- 3.46094675544156
        add.sd <- c(0, 0.69440834572668)
        eta.ka ~ 0.398603552033134
        eta.cl ~ 0.0698037655868484
        eta.v ~ 0.0197915335185721
    })
    model({
        ka <- exp(tka + eta.ka)
        cl <- exp(tcl + eta.cl)
        v <- exp(tv + eta.v)
        d/dt(depot) <- -ka * depot
        d/dt(center) <- ka * depot - cl/v * center
        cp <- center/v
        cp ~ add(add.sd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "oneCompartment", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

