ui <- function () 
{
    ini({
        e0 <- 4.28980468856388
        slope <- 0.0519649061250291
        addSd <- c(0, 0.791684193424161)
    })
    model({
        effect <- e0 + slope * conc
        effect ~ add(addSd)
    })
}
ui <- rxode2::rxode2(ui)
ui <- rxode2::rxUiDecompress(ui)
assign("modelName", "modLinear", envir=, ui)
rm("model", envir=ui)
ui <- rxode2::rxUiCompress(ui)

